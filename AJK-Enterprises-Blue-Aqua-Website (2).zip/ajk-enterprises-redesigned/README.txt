AJK ENTERPRISES website package
Open index.html in a browser for a local preview.
The original company logo is included in assets/ajk-enterprises-logo.png and enlarged in the header, footer and admin branding.
For live deployment, upload this ZIP to Netlify Drop or deploy the extracted folder.
Note: secure shared admin management requires a configured backend and database.
